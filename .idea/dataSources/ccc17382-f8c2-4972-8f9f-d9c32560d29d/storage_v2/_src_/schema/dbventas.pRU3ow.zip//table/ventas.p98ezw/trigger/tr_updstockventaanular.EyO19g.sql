create definer = root@localhost trigger tr_updStockVentaAnular
    after update
    on ventas
    for each row
BEGIN
 UPDATE articulos a
   JOIN detalle_ventas dv
   ON dv.idarticulo = a.id
   AND dv.idventa = NEW.id
   SET a.stock = a.stock+dv.cantidad;
   
  END;

