create definer = root@localhost trigger tr_updStockVenta
    after insert
    on detalle_ventas
    for each row
BEGIN
 UPDATE articulos SET stock = stock - NEW.cantidad
 WHERE articulos.id = NEW.idarticulo;
END;

