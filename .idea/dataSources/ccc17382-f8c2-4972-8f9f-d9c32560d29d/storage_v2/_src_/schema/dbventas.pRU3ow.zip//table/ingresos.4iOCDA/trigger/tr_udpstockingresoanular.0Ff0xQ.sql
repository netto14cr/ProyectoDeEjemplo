create definer = root@localhost trigger tr_udpStockIngresoAnular
    after update
    on ingresos
    for each row
BEGIN
 UPDATE articulos a
 JOIN detalle_ingresos di
 ON di.idarticulo = a.id
 AND di.idingreso = new.id
 SET a.stock = a.stock - di.cantidad;
 
END;

