create definer = root@localhost trigger tr_updStockIngreso
    after insert
    on detalle_ingresos
    for each row
BEGIN
 UPDATE articulos SET stock = stock + NEW.cantidad 
 WHERE articulos.id = NEW.idarticulo;
END;

